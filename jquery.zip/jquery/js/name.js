var frm = $("#textform");
var dataName;
frm.submit(function (e) {
  e.preventDefault();

  $.ajax({
    type: "POST",
    url: "http://192.168.0.143:5000/process",
    // async: false,
    data: JSON.stringify({ text: $("#text").val() }),
    contentType: "application/json; charset=utf-8",
    dataType: "json",
    success: function (data) {
      console.log("Submission was successful.");
      console.log(data);
      $("#successText").text(data.name).show();

      $("#optionOK").show();
      $("#optionNotOK").show();

      dataName = data.name;
      let radioHTML = "";
      $.each(data.options, function (index, value) {
        radioHTML += '<label><input type="radio" name="radio_group" id="option" value="' + value + '"> ' + value + "</label><br>";
      });

      $("#radio-group").html(radioHTML);
    },
    error: function (data) {
      console.log("An error occurred.");
      console.log(data);
    },
  });
});

var frm1 = $("#optionform");

frm1.submit(function (e) {
  e.preventDefault();
  $.ajax({
    type: "POST",
    url: "http://192.168.0.143:5000/store",
    // async: false,
    data: JSON.stringify({ text: $("#text").val(), option: $('input[name="radio_group"]:checked').val() }),
    contentType: "application/json; charset=utf-8",
    dataType: "json",
    success: function (data) {
      console.log("Submission was successful.");
      console.log(data);
      $("#successNotOk").text(data.status).show();
    },
    error: function (data) {
      console.log("An error occurred.");
      console.log(data);
    },
  });
});

$("#optionOK").click(function (e) {
  $("#optionform").hide();
  $("#successNotOk").hide();

  e.preventDefault();
  $.ajax({
    type: "POST",
    url: "http://192.168.0.143:5000/store",
    // async: false,
    data: JSON.stringify({ text: $("#text").val(), option: dataName }),
    contentType: "application/json; charset=utf-8",
    dataType: "json",
    success: function (data) {
      console.log("Submission was successful.");
      console.log(data);
      $("#successok").text(data.status).show();
    },
    error: function (data) {
      console.log("An error occurred.");

      console.log(data);
    },
  });
});

$("#optionNotOK").click(function (e) {
  $("#optionform").show();
  $("#successok").hide();
});
